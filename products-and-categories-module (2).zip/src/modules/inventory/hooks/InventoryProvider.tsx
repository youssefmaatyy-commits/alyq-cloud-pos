import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { AppError } from "@/modules/products/data/repository";
import { stockStatus, type Product, type StockStatus } from "@/modules/products/types";
import { getInventoryMode, getInventoryRepository } from "../data";
import type { InventoryRepository } from "../data/repository";
import {
  adjustStock as adjustStockService,
  loadInventory,
  type InventoryAdjustmentResult,
} from "../services/inventoryService";
import { getCurrentUser, setCurrentUser, canAdjustStock, type InventoryUser } from "../permissions";
import type { StockMovement, StockMovementType, StockReason } from "../types";

export interface InventoryContextValue {
  mode: "supabase" | "demo";
  repository: InventoryRepository;
  products: Product[];
  movements: StockMovement[];
  loading: boolean;
  error: AppError | null;
  refresh: () => Promise<void>;
  adjustStock: (args: {
    productId: string;
    type: StockMovementType;
    reason: StockReason;
    quantity: number;
    notes: string | null;
  }) => Promise<InventoryAdjustmentResult>;
  /** Convenience selectors. */
  productById: (id: string) => Product | undefined;
  movementsForProduct: (id: string) => StockMovement[];
  /** Permission helpers. */
  user: InventoryUser;
  canAdjust: boolean;
  /** Switch the acting user (Phase 3 stand-in for real auth). */
  setUser: (user: InventoryUser) => void;
  /** Read-only derived status. */
  statusOf: (id: string) => StockStatus;
}

const InventoryContext = createContext<InventoryContextValue | null>(null);

/** Loads the inventory once and exposes validated mutations to the pages. */
export function InventoryProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<AppError | null>(null);
  const [user, setUser] = useState<InventoryUser>(() => getCurrentUser());

  const repository = useMemo(() => getInventoryRepository(), []);
  const mode = useMemo(() => getInventoryMode(), []);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const snapshot = await loadInventory();
      setProducts(snapshot.products);
      setMovements(snapshot.movements);
    } catch (err) {
      setError(err as AppError);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const adjustStock = useCallback(
    async (args: {
      productId: string;
      type: StockMovementType;
      reason: StockReason;
      quantity: number;
      notes: string | null;
    }) => {
      if (!canAdjustStock(user)) {
        throw Object.assign(new Error("FORBIDDEN"), { code: "FORBIDDEN" });
      }
      const result = await adjustStockService(args);
      // Optimistic: keep the local lists consistent without waiting for `refresh`.
      setProducts((prev) =>
        prev.map((p) => (p.id === result.product.id ? result.product : p)),
      );
      setMovements((prev) => [result.movement, ...prev]);
      return result;
    },
    [user],
  );

  const changeUser = useCallback((next: InventoryUser) => {
    setCurrentUser(next);
    setUser(next);
  }, []);

  const productById = useCallback(
    (id: string) => products.find((p) => p.id === id),
    [products],
  );

  const movementsForProduct = useCallback(
    (id: string) => movements.filter((m) => m.product_id === id),
    [movements],
  );

  const statusOf = useCallback(
    (id: string) => {
      const product = products.find((p) => p.id === id);
      if (!product) return "none" as StockStatus;
      return stockStatus(product);
    },
    [products],
  );

  const value = useMemo<InventoryContextValue>(
    () => ({
      mode,
      repository,
      products,
      movements,
      loading,
      error,
      refresh,
      adjustStock,
      productById,
      movementsForProduct,
      user,
      canAdjust: canAdjustStock(user),
      statusOf,
      setUser: changeUser,
    }),
    [mode, repository, products, movements, loading, error, refresh, adjustStock, productById, movementsForProduct, user, statusOf, changeUser],
  );

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>;
}

export function useInventory(): InventoryContextValue {
  const ctx = useContext(InventoryContext);
  if (!ctx) throw new Error("useInventory must be used inside <InventoryProvider>");
  return ctx;
}
