import { useI18n } from "@/lib/i18n/I18nProvider";
import { Button, SelectInput, TextInput } from "@/components/ui";
import { usePos } from "../hooks/PosProvider";
import { validateDiscount } from "../services/posMath";
import { CustomerSearchSelect } from "@/modules/customers/components/CustomerSearchSelect";

/**
 * Cart panel — the right side of the register.
 * Shows lines, qty steppers (capped at available stock), discount controls
 * and authoritative totals. Discounts are locked unless the current user is
 * authorized (manager / admin).
 */
export function CartPanel() {
  const { t, num } = useI18n();
  const {
    lines,
    totals,
    discount,
    setDiscount,
    increase,
    decrease,
    removeLine,
    isEmpty,
    canDiscount,
    selectedCustomer,
    setSelectedCustomer,
  } = usePos();

  const discountError = validateDiscount(discount.type, discount.value);

  if (isEmpty) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center">
        <span aria-hidden className="text-3xl">🧾</span>
        <p className="text-sm font-bold text-slate-900">{t("pos.emptyCart")}</p>
        <p className="text-xs font-medium text-slate-500">{t("pos.emptyCartHint")}</p>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col gap-3 overflow-hidden rounded-2xl border border-slate-200 bg-white">
      <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
        <p className="text-sm font-bold text-slate-900">{t("pos.cart")}</p>
        <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-bold text-indigo-800 ring-1 ring-inset ring-indigo-200">
          {lines.reduce((s, l) => s + l.qty, 0)}
        </span>
      </div>

      <div className="border-b border-slate-100 px-4 py-2.5">
        <CustomerSearchSelect
          selectedCustomerId={selectedCustomer?.id ?? null}
          onSelect={(c) => setSelectedCustomer(c)}
        />
      </div>

      {/* lines */}
      <ul className="flex-1 divide-y divide-slate-100 overflow-y-auto px-2">
        {lines.map((line) => (
          <li key={line.product_id} className="flex items-center gap-2 px-2 py-2.5">
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-slate-900">
                {line.name_en || line.name_ar}
              </p>
              <p className="mt-0.5 flex items-center gap-2 font-mono text-[10px] text-slate-500">
                <span>{line.sku}</span>
                <span className="tabular-nums">{num(line.unit_price, 2)}</span>
              </p>
            </div>

            {/* qty stepper */}
            <div className="flex items-center gap-1">
              <Button
                variant="secondary"
                size="sm"
                className="h-7 w-7 !px-0"
                onClick={() => decrease(line.product_id)}
                aria-label="−"
              >
                −
              </Button>
              <span className="w-8 text-center text-sm font-bold tabular-nums text-slate-900">
                {line.qty}
              </span>
              <Button
                variant="secondary"
                size="sm"
                className="h-7 w-7 !px-0"
                disabled={line.qty >= line.max_qty}
                onClick={() => increase(line.product_id)}
                aria-label="+"
              >
                +
              </Button>
            </div>

            <div className="w-20 text-end">
              <p className="text-xs font-bold tabular-nums text-slate-900">
                {num(line.unit_price * line.qty, 2)}
              </p>
              {line.qty >= line.max_qty ? (
                <p className="text-[10px] font-semibold text-amber-600">
                  {t("inventory.status.low")}: {line.max_qty}
                </p>
              ) : null}
            </div>

            <button
              type="button"
              onClick={() => removeLine(line.product_id)}
              aria-label="×"
              className="flex h-6 w-6 items-center justify-center rounded-md text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
            >
              ×
            </button>
          </li>
        ))}
      </ul>

      {/* discount */}
      <div className="border-t border-slate-100 px-4 py-3">
        <div className="mb-2 flex items-center gap-2">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-600">
            {t("pos.discount")}
          </p>
          {!canDiscount ? (
            <span className="rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-800 ring-1 ring-inset ring-amber-300">
              🔒 {t("pos.discountLocked")}
            </span>
          ) : null}
        </div>
        <div className="flex gap-2">
          <SelectInput
            value={discount.type}
            disabled={!canDiscount}
            onChange={(e) => setDiscount({ ...discount, type: e.target.value as typeof discount.type })}
            aria-label={t("pos.discount")}
            className="h-9 w-40 py-1 text-xs"
          >
            <option value="none">{t("pos.discountType.none")}</option>
            <option value="percent">{t("pos.discountType.percent")}</option>
            <option value="fixed">{t("pos.discountType.fixed")}</option>
          </SelectInput>
          {discount.type !== "none" ? (
            <>
              <TextInput
                dir="ltr"
                inputMode="decimal"
                disabled={!canDiscount}
                value={String(discount.value)}
                invalid={Boolean(discountError)}
                onChange={(e) => setDiscount({ ...discount, value: Number(e.target.value) })}
                placeholder={t("pos.discountValue")}
                className="h-9 py-1 text-xs"
              />
              {discountError ? (
                <p className="text-[11px] font-semibold text-rose-600">
                  {discountError === "tooHigh" ? t("pos.discountTooHigh") : t("pos.discountInvalid")}
                </p>
              ) : null}
            </>
          ) : null}
        </div>
      </div>

      {/* totals */}
      <div className="border-t border-slate-100 px-4 py-3 text-sm">
        <div className="flex items-center justify-between text-slate-600">
          <span>{t("pos.subtotal")}</span>
          <span className="tabular-nums">{num(totals.subtotal, 2)}</span>
        </div>
        <div className="mt-1 flex items-center justify-between text-slate-600">
          <span>{t("pos.discount")}</span>
          <span className="tabular-nums text-rose-600">−{num(totals.discountAmount, 2)}</span>
        </div>
        <div className="mt-2 flex items-center justify-between border-t border-slate-200 pt-2 text-base font-extrabold text-slate-900">
          <span>{t("pos.total")}</span>
          <span className="tabular-nums">{num(totals.total, 2)}</span>
        </div>
      </div>
    </div>
  );
}
